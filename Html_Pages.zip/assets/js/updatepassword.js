function updatepassword(){
   let New_Password= document.getElementById("New_Password").value;
    let Confirm_password = document.getElementById("Confirm_password").value;
  console.log(New_Password,Confirm_password);
//   location.href = "../../Html_Pages/updatePassword.html";
//   window.location.href = '/Html_Pages/updatePassword.html';
}


